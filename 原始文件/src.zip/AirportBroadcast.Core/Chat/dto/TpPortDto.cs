﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirportBroadcast.Chat.Dto
{
    public class TpPortDto
    {
        public bool P1 { get; set; }
        public bool P2 { get; set; }

        public bool P3 { get; set; }

        public bool P4 { get; set; }

        public bool P5 { get; set; }
        public bool P6 { get; set; }

        public bool P7 { get; set; }

        public bool P8 { get; set; }
    }
}

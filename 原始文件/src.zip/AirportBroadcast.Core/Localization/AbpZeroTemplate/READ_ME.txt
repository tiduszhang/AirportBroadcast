﻿ABOUT LOCALIZATION FILES
------------------------------------------------------------
This folder contains localization files for the application.

You can add more languages here with appropriate postfixes.
For instance, to add a German localization, you can add "AbpZeroTemplate-de.xml" or "AbpZeroTemplate-de-DE.xml".

IMPORTANT: All XML files must be "embedded resource".

See http://www.aspnetboilerplate.com/Pages/Documents/Localization for more information.
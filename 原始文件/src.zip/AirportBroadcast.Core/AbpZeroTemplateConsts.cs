﻿namespace AirportBroadcast
{
    /// <summary>
    /// Some general constants for the application.
    /// </summary>
    public class AbpZeroTemplateConsts
    {
        public const string LocalizationSourceName = "AbpZeroTemplate";//AbpZeroTemplate

        public const bool MultiTenancyEnabled = false;
    }
}
﻿using System.Collections.Generic;

namespace AirportBroadcast.Logging.Dto
{
    public class GetLatestWebLogsOutput
    {
        public List<string> LatesWebLogLines { get; set; }
    }
}

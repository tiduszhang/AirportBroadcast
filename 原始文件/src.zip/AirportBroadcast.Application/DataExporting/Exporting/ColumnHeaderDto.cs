﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirportBroadcast.DataExporting.Exporting
{
    public class ColumnHeaderDto
    {
        public string ColFiled { get; set; }

        public string ColName { get; set; }
    }
}

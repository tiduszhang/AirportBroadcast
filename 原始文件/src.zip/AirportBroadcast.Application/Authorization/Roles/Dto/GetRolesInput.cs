﻿using Abp.Application.Services.Dto;

namespace AirportBroadcast.Authorization.Roles.Dto
{
    public class GetRolesInput 
    {
        public string Permission { get; set; }
    }
}

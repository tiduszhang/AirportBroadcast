﻿using Abp.Application.Services; 

namespace AirportBroadcast.Tenants.Dashboard
{
    public interface ITenantDashboardAppService : IApplicationService
    { 
       
    }
}

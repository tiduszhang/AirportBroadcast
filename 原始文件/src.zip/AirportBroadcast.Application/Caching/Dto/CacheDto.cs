﻿using Abp.Application.Services.Dto;

namespace AirportBroadcast.Caching.Dto
{
    public class CacheDto
    {
        public string Name { get; set; }
    }
}

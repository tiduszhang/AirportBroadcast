﻿using Abp.Configuration;

namespace AirportBroadcast.Timing.Dto
{
    public class GetTimezonesInput
    {
        public SettingScopes DefaultTimezoneScope;
    }
}
